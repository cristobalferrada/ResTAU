/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import Clases.Ingrediente;
import Clases.Conexion_BD;
import java.sql.*;

/**
 *
 * @author tobal
 */
public class Manejadora {
     //CRUD INGREDIENTES
     public static boolean agregarIngrediente (Ingrediente p)
    {
        try 
        {
            Connection conn = Conexion_BD.getConexion_BD();
            
            String query = "insert into INGREDIENTE (id_ingrediente,nombre_ingrediente,stock) values (?,?,?)";
            PreparedStatement insertar = conn.prepareCall(query);
            insertar.setInt(1, p.getId_ingrediente());
            insertar.setString(2, p.getNombre_ingrediente());
            insertar.setInt(3, p.getStock());        
            insertar.execute();
            insertar.close();
            conn.close();
            
            return true;
        } catch (SQLException e)
        {
            System.out.println("Error de sql" +e.getMessage());
            return false;
        }
    }

     
     
    public static void eliminarIngrediente(int fila,String nom_prod) throws ClassNotFoundException {
    
        Connection reg =  Conexion_BD.getConexion_BD();
        try
        {
        
        PreparedStatement pst = reg.prepareStatement("DELETE FROM INGREDIENTE where nombre_ingrediente=('"+nom_prod+"')");
        pst.executeUpdate();
  
        }catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }
    
     public static ResultSet mostrarIngrediente() throws ClassNotFoundException
    {
        ResultSet rs=null;
        try{
        Connection conexion = Conexion_BD.getConexion_BD();
        String query = "select * from INGREDIENTE";
        PreparedStatement mostrar = conexion.prepareStatement(query);
        rs = mostrar.executeQuery(); 
        }
        catch(SQLException e)
        {
           System.out.println(e.getMessage());
        } 
        return(rs);
    } 
    
    public static ResultSet buscarIngrediente (String nombre_ingrediente) throws ClassNotFoundException
    {
        ResultSet rs=null;
        try{
        Connection conexion = Conexion_BD.getConexion_BD();
        String query = "select * from INGREDIENTE where nombre_ingrediente=('"+nombre_ingrediente+"')";
        PreparedStatement busca = conexion.prepareStatement(query);
        rs = busca.executeQuery(); 
        
        }
        catch(SQLException e)
        {
           System.out.println(e.getMessage());
        } 
        return(rs);
    }  
    
     public static boolean actualizarIngrediente (Ingrediente p)
    {
        try 
        {
            String v_sub_nomprod = p.getNombre_ingrediente();
            Connection conn = Conexion_BD.getConexion_BD();
            
            String query = "update INGREDIENTE set ID_INGREDIENTE=(?), NOMBRE_INGREDIENTE=?, STOCK=? where NOMBRE_INGREDIENTE =('" +v_sub_nomprod+"')";
            PreparedStatement insertar = conn.prepareCall(query);
            insertar.setInt(1, p.getId_ingrediente());
            insertar.setString(2, p.getNombre_ingrediente());
            insertar.setInt(3, p.getStock());
            insertar.execute();
            insertar.close();
            conn.close();
            
            return true;
        } catch (SQLException e)
        {
            System.out.println("Error de sql" +e.getMessage());
            return false;
        }
    }
    
    
}
